//Name: Richard John
//Instructor: Professor Richard Thomas Weir
//Class: CSC 330
//Assignment: Pokemon Lab
//Date: April 5, 2021

public interface Item {

    //Only method. And its public.
    public void use(Pokemon p);
}
